-- NewIcons
-- Author: arian
-- DateCreated: 6/27/2024 6:53:51 PM
--------------------------------------------------------------
INSERT INTO IconTextureAtlases (Name, IconSize, IconsPerRow, IconsPerColumn, Filename)
VALUES	('ICON_ATLAS_CORCEGA_BDD_G4', 22, 1, 1, 'CorcegaAtlas22.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 30, 1, 1,	'CorcegaAtlas30.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 36, 1, 1, 'CorcegaAtlas36.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 44, 1, 1,	'CorcegaAtlas44.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 48, 1, 1, 'CorcegaAtlas48.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 50, 1, 1,	'CorcegaAtlas50.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 64, 1, 1,	'CorcegaAtlas64.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 80, 1, 1, 'CorcegaAtlas80.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 200, 1, 1, 'CorcegaAtlas200.dds'),
		('ICON_ATLAS_CORCEGA_BDD_G4', 256, 1, 1, 'CorcegaAtlas256.dds'),

		('ICON_ATLAS_LUFFY_BDD_G4', 32, 1, 1, 'LuffyIcon32.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 45, 1, 1, 'LuffyIcon45.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 48, 1, 1, 'LuffyIcon48.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 50, 1, 1, 'LuffyIcon50.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 55, 1, 1, 'LuffyIcon55.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 64, 1, 1, 'LuffyIcon64.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 80, 1, 1, 'LuffyIcon80.dds'),
		('ICON_ATLAS_LUFFY_BDD_G4', 256, 1, 1, 'LuffyIcon256.dds'),
		
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 22, 2, 1, 'GuardiaimperialAtlas22.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 32, 2, 1,	'GuardiaimperialAtlas32.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 38, 2, 1, 'GuardiaimperialAtlas38.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 50, 2, 1,	'GuardiaimperialAtlas50.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 70, 2, 1,	'GuardiaimperialAtlas70.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 80, 2, 1,	'GuardiaimperialAtlas80.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 95, 2, 1, 'GuardiaimperialAtlas95.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 200, 2, 1, 'GuardiaimperialAtlas200.dds'),
		('ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 256, 2, 1, 'GuardiaimperialAtlas256.dds'),
		
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 38, 1, 1, 'Palacioimperial38.dds'),
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 40, 1, 1, 'Palacioimperial40.dds'),
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 50, 1, 1, 'Palacioimperial50.dds'),
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 80, 1, 1, 'Palacioimperial80.dds'),
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 200, 1, 1, 'Palacioimperial200.dds'),
		('ICON_ATLAS_PALACIOIMPERIAL_BDD_G4', 256, 1, 1, 'Palacioimperial256.dds');


INSERT INTO IconDefinitions (Name, Atlas, 'Index')
VALUES	('ICON_CIVILIZATION_CORCEGA_BDD_G4', 'ICON_ATLAS_CORCEGA_BDD_G4', 0),
		('ICON_LEADER_LUFFY_BDD_G4', 'ICON_ATLAS_LUFFY_BDD_G4', 0),
		('ICON_UNIT_GUARDIAIMPERIAL_PORTRAIT_BDD_G4', 'ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4', 0),
		('ICON_UNIT_GUARDIAIMPERIAL_BDD_G4', 'ICON_ATLAS_GUARDIAIMPERIAL_BDD_G4',�1);