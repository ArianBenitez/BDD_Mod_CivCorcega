-- Building
-- Author: arian
-- DateCreated: 6/27/2024 6:51:45 PM
--------------------------------------------------------------
INSERT INTO Types (Type, Kind)
VALUES ('BUILDING_PALACIO_IMPERIAL_BDD_G4', 'KIND_BUILDING');

INSERT INTO Buildings (BuildingType, Name, Cost, PrereqDistrict, Description, Maintenance, ObsoleteEra, AdvisorType)
VALUES ('BUILDING_PALACIO_IMPERIAL_BDD_G4', 'LOC_BUILDING_PALACIO_IMPERIAL_BDD_G4_NAME', 400, 'DISTRICT_CITY_CENTER', 'LOC_BUILDING_PALACIO_IMPERIAL_BDD_G4_DESCRIPTION', 1, 'ERA_INDUSTRIAL', 'ADVISOR_GENERIC');

INSERT INTO CivilizationBuildings (BuildingType, CivilizationType)
VALUES ('BUILDING_PALACIO_IMPERIAL_BDD_G4', 'CIVILIZATION_CORCEGA_BDD_G4');