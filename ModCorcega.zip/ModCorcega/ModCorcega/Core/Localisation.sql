-- Localisation
-- Author: arian
-- DateCreated: 6/27/2024 6:50:19 PM
--------------------------------------------------------------
INSERT INTO LocalizedText (Language, Tag, Text)
VALUES ('es_ES', 'LOC_CIVILIZATION_CORCEGA_BDD_G4_NAME', 'Imperio Corsa'),
	   ('es_ES', 'LOC_CIVILIZATION_CORCEGA_BDD_G4_DESCRIPTION', 'Una civilizaci�n conocida por su ambici�n militar y cultural.'),
	   ('es_ES', 'LOC_CIVILIZATION_CORCEGA_BDD_G4_ADJECTIVE', 'Corsa'),
	   -- Building Text
	   ('es_ES', 'LOC_BUILDING_PALACIO_IMPERIAL_BDD_G4_NAME', 'Palacio Imperial'),
       ('es_ES', 'LOC_BUILDING_PALACIO_IMPERIAL_BDD_G4_DESCRIPTION', 'Un edificio que refleja el poder y la grandeza del Imperio�Corsa.');
	   -- Unique Unit
	   ('es_ES', 'LOC_UNIT_GUARDIA_IMPERIAL_LUFFY_BDD_G4_NAME', 'Ejercito Luffy'),
	   ('es_ES', 'LOC_UNIT_GUARDIA_IMPERIAL_LUFFY_BDD_G4_DESCRIPTION', 'Una unidad militar terrestre de �lite de la era industrial.'),
	   ('es_ES', 'LOC_ABILITY_GUARDIA_IMPERIAL_LUFFY_BDD_G4', '+5 [ICON_Strength] Combat Strength'),
	   -- Cities
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_1',  'Ajaccio'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_2',  'Bastia'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_3',  'Calvi'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_4',  'Corte'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_5',  'Porto-Vecchio'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_6',  'Sart�ne'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_7',  'Bonifacio'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_8',  'Saint-Florent'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_9',  '�le-Rousse'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_10',  'Propriano'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_11',  'Al�ria'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_12',  'Ghisonaccia'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_13',  'Lile-Rousse'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_14',  'Penta-di-Casinca'),
	   ('es_ES',	'LOC_CITY_NAME_CORCEGA_15',  'Morosaglia'),
	   -- Info de la civilizaci�n
	   ('es_ES', 'LOC_CIVINFO_BDD_G4_LOCATION', 'Francia'),
	   ('es_ES', 'LOC_CIVINFO_BDD_G4_SIZE', '8680 km�'),
	   ('es_ES', 'LOC_CIVINFO_BDD_G4_POPULATION', '322.000'),
	   ('es_ES', 'LOC_CIVINFO_BDD_G4_CAPITAL', 'Ajaccio'),
	   -- Info que aparecer� en la Civilopedia
	   ('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CORCEGA_BDD_G4_CHAPTER_HISTORY_PARA_1', 'La isla de C�rcega, situada en el mar Mediterr�neo, ha sido habitada desde tiempos prehist�ricos. Los primeros colonizadores documentados fueron los griegos, quienes establecieron la colonia de Alalia alrededor del a�o 565 a.C. Sin embargo, fueron los romanos quienes dejaron una marca indeleble en la isla tras conquistarla en el a�o 238 a.C., convirti�ndola en una provincia romana. Bajo el dominio romano, C�rcega se desarroll� econ�micamente, especialmente en la agricultura y el comercio, pero tambi�n sufri� de constantes incursiones de piratas y tribus b�rbaras.'),
	   ('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CORCEGA_BDD_G4_CHAPTER_HISTORY_PARA_2', 'Tras la ca�da del Imperio Romano, C�rcega fue invadida por varios grupos, incluyendo los v�ndalos y los ostrogodos, antes de ser incorporada al Imperio Bizantino. Sin embargo, la isla nunca estuvo completamente bajo control centralizado hasta que la Rep�blica de G�nova tom� el poder en el siglo XIII. Los genoveses gobernaron C�rcega durante siglos, construyendo numerosas fortalezas y torres costeras para protegerse de las incursiones piratas y establecer un control m�s firme sobre la isla.'),
  	   ('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CORCEGA_BDD_G4_CHAPTER_HISTORY_PARA_3', 'El dominio genov�s fue resistido por los corsos, quienes desarrollaron un fuerte sentido de identidad y deseo de independencia. En el siglo XVIII, Pasquale Paoli emergi� como un l�der carism�tico que encabez� la lucha por la independencia de G�nova. En 1755, Paoli proclam� la Rep�blica de C�rcega, introduciendo una constituci�n democr�tica que fue una de las primeras de su tipo en el mundo. Sin embargo, la independencia fue ef�mera. En 1768, G�nova cedi� C�rcega a Francia, y tras un a�o de resistencia, la isla fue finalmente incorporada al Reino de Francia.'),
	   ('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CORCEGA_BDD_G4_CHAPTER_HISTORY_PARA_4', 'A lo largo de los siglos XIX y XX, C�rcega continu� siendo una parte de Francia, aunque mantuvo una identidad cultural distintiva. La isla es conocida como el lugar de nacimiento de Napole�n Bonaparte en 1769, quien m�s tarde se convertir�a en uno de los l�deres militares y pol�ticos m�s influyentes de Europa. En el siglo XX, el sentimiento autonomista resurgi�, y en a�os recientes, ha habido movimientos significativos para la preservaci�n de la lengua y cultura corsa, as� como demandas por mayor autonom�a dentro del Estado franc�s.');
	   -- Unique Unit Civilopedia
	   ('es_ES', 'LOC_PEDIA_UNITS_PAGE_UNIT_GUARDIA_IMPERIAL_LUFFY_CHAPTER_HISTORY_PARA_1_BDD_G4', 'Una unidad militar terrestre de �lite de la era industrial.');