-- HistoricMoments
-- Author: arian
-- DateCreated: 6/28/2024 11:09:26 AM
--------------------------------------------------------------
INSERT INTO MomentIllustrations (MomentIllustrationType, MomentDataType, GameDataType, Texture)
VALUES ('MOMENT_ILLUSTRATION_UNIQUE_UNIT_BDD_G4', 'MOMENT_DATA_UNIT_BDD_G4', 'UNIT_GUARDIA_IMPERIAL_BDD_G4', 'GuardiaImperialHistoricMoment.dds'),
	   ('MOMENT_ILLUSTRATION_UNIQUE_BUILDING_BDD_G4', 'MOMENT_DATA_BUILDING_BDD_G4', 'BUILDING_PALACIO_IMPERIAL_BDD_G4', 'PalacioImperialHistoricMoment.dds');