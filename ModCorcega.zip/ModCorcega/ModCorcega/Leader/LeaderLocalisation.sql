-- LeaderLocalisation
-- Author: arian
-- DateCreated: 6/27/2024 6:58:08 PM
--------------------------------------------------------------
INSERT INTO LocalizedText (Language, Tag, text)
VALUES ('es_ES', 'LOC_LEADER_LUFFY_BDD_G4_NAME', 'Monkey D.Luffy'),
	   ('es_ES', 'LOC_LEADER_LUFFY_BDD_G4_DESCRIPTION', 'Un l�der pirata intr�pido y carism�tico que persigue su sue�o de encontrar el One Piece y convertirse en el Rey de los Piratas, inspirando a su leal tripulaci�n con su valent�a y esp�ritu indomable.'),

	   --Habilidad �nica
	   ('es_ES', 'LOC_TRAIT_LEADER_GRAN_ARMEE_BDD_G4_NAME', 'Gran Arm�e'),
       ('es_ES', 'LOC_TRAIT_LEADER_GRAN_ARMEE_BDD_G4_DESCRIPTION', 'Las unidades militares terrestres reciben un bonus de combate adicional cuando est�n en su continente de origen (Europa).'),

	   --LiderAgenda
	   ('es_ES', 'LOC_AGENDA_LUFFY_BDD_G4_NAME', 'Agenda de Monkey D.Luffy'),
	   ('es_ES', 'LOC_AGENDA_LUFFY_BDD_G4_DESCRIPTION', 'Un l�der pirata intr�pido y carism�tico que persigue su sue�o de encontrar el One Piece y convertirse en el Rey de los Piratas, inspirando a su leal tripulaci�n con su valent�a y esp�ritu indomable.'),

	   --Pantalla de carga
	   ('es_ES', 'LOC_LOADING_INFO_LEADER_LUFFY_BDD_G4', 'Convi�rtete en el Rey de los Piratas, Monkey D. Luffy, un l�der cuya determinaci�n y valent�a inspiran a su leal tripulaci�n en la b�squeda del legendario One Piece. Tu indomable esp�ritu y habilidad para forjar alianzas te guiar�n a trav�s de los peligrosos mares, enfrentando desaf�os con una sonrisa y llevando la esperanza a todos los rincones del mundo. �Que tu viaje comience, Sombrero de Paja!'),
	 
	   --Quote y civilopedia
	   ('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LUFFY_BDD_G4_QUOTE', 'Ser� el Rey de los Piratas, porque nunca dejar� de perseguir mis sue�os, sin importar cu�ntas veces me caiga o cu�ntos enemigos se interpongan en mi camino. - Monkey D. Luffy'),
	   ('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LUFFY_BDD_G4_TITLE', 'Monkey D.Luffy'),
	   ('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_LUFFY_BDD_G4_CHAPTER_HISTORY_PARA_1', 'Monkey D. Luffy, tambi�n conocido como "Luffy Sombrero de Paja", es el carism�tico y valiente capit�n de los Piratas del Sombrero de Paja. Nacido en el pueblo de Foosha, en el East Blue, Luffy creci� inspirado por el legendario pirata Shanks "El Pelirrojo". Tras consumir la fruta del diablo Gomu Gomu, Luffy adquiri� habilidades el�sticas, lo que le otorga una ventaja �nica en combate.'),
	   ('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_LUFFY_BDD_G4_CHAPTER_HISTORY_PARA_2', 'Su sue�o es encontrar el legendario tesoro conocido como One Piece y convertirse en el Rey de los Piratas. Con una voluntad inquebrantable y un coraz�n lleno de determinaci�n, Luffy lidera a su variopinta tripulaci�n, gan�ndose su lealtad y enfrentando innumerables desaf�os en su viaje.'),
	   ('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_LUFFY_BDD_G4_CHAPTER_HISTORY_PARA_3', 'Luffy es conocido por su apetito insaciable, especialmente por la carne, y por su capacidad de hacer amigos y aliados dondequiera que va. Su sentido de la justicia, valent�a y la creencia en la libertad lo convierten en un l�der inspirador y una figura emblem�tica en el vasto mundo de los piratas.'),
	   --Info que aparecer� en la Civilopedia
	   ('es_ES', 'LOC_PEDIA_UNITS_PAGE_UNIT_LUFFY_BDD_G4_CHAPTER_HISTORY_PARA_1', 'Guardia Imperial\n\nUnidad Exclusiva del Imperio Corsa\n\nReemplaza a: Infanter�a\n\nFuerza de Combate: 55\nCoste de Producci�n: 120\nEra: Industrial\nClase de Promoci�n: Infanter�a\n\nDescripci�n:\nLa Guardia Imperial es la unidad exclusiva del Imperio Corsa bajo el liderazgo de Napole�n Bonaparte. Esta formidable infanter�a representa la �lite de las fuerzas militares corsas durante la era industrial, inspirada en las legendarias tropas napole�nicas. La Guardia Imperial es conocida por su disciplina inquebrantable, su valent�a en el campo de batalla y su lealtad absoluta a su comandante.\n\nBonificaciones �nicas:\n- La Guardia Imperial recibe un bono de combate adicional en terrenos llanos, reflejando su capacidad de realizar cargas decisivas en condiciones favorables.\n- Adem�s, la unidad tiene una resistencia superior al da�o, representando su mayor capacidad de recuperaci�n y tenacidad en batalla prolongada.\n\nHistoria:\nLa Guardia Imperial, inspirada en las fuerzas de �lite de Napole�n Bonaparte, desempe�� un papel crucial en muchas de sus campa�as militares. Estas unidades estaban compuestas por los soldados m�s experimentados y mejor entrenados, seleccionados por su valor y habilidades excepcionales. En la realidad alternativa del Imperio Corsa, esta unidad simboliza el poder y la influencia militar de Napole�n, adaptada a la resistencia y esp�ritu independiente de la isla de C�rcega.\n\nUso Estrat�gico:\nUtiliza la Guardia Imperial para asegurar la superioridad en combates terrestres durante la era industrial. Su fuerza de combate elevada y sus bonificaciones en terrenos llanos hacen de esta unidad una opci�n excelente para ofensivas decisivas y defensa robusta en los momentos cr�ticos de la partida.');
	   
