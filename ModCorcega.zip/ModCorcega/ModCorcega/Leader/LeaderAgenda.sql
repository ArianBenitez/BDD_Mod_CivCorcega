-- LeaderAgenda
-- Author: arian
-- DateCreated: 6/27/2024 6:55:31 PM
--------------------------------------------------------------
INSERT INTO Types (Type, Kind)
VALUES ('TRAIT_AGENDA_LUFFY_BDD_G4', 'KIND_TRAIT');

INSERT INTO Agendas (AgendaType, Name, Description)
VALUES ('AGENDA_LUFFY_BDD_G4', 'LOC_AGENDA_LUFFY_BDD_G4_NAME', 'LOC_AGENDA_LUFFY_BDD_G4_DESCRIPTION');

INSERT INTO Traits (TraitType, Name, Description)
VALUES ('TRAIT_AGENDA_LUFFY_BDD_G4', 'LOC_AGENDA_LUFFY_BDD_G4_NAME', 'LOC_AGENDA_LUFFY_BDD_G4_DESCRIPTION');

INSERT INTO AgendaTraits (AgendaType, TraitType)
VALUES ('AGENDA_LUFFY_BDD_G4', 'TRAIT_AGENDA_LUFFY_BDD_G4');

INSERT INTO HistoricalAgendas (LeaderType, AgendaType)
VALUES ('LEADER_LUFFY_BDD_G4', 'AGENDA_LUFFY_BDD_G4');

