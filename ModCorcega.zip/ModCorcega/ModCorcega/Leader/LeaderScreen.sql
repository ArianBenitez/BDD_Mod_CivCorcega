-- LeaderScreen
-- Author: arian
-- DateCreated: 6/27/2024 6:58:58 PM
--------------------------------------------------------------
INSERT INTO LoadingInfo (LeaderType, ForegroundImage, BackgroundImage, PlayDawnOfManAudio)
VALUES ('LEADER_LUFFY_BDD_G4', 'LEADER_LUFFY_NEUTRAL', 'LEADER_LUFFY_BACKGROUND', 0);

INSERT INTO DiplomacyInfo (Type, BackgroundImage)
VALUES ('LEADER_LUFFY_BDD_G4', 'LEADER_LUFFY_DIPLO_BG');