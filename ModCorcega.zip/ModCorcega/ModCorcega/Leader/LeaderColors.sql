-- LeaderColors
-- Author: arian
-- DateCreated: 6/27/2024 6:55:54 PM
--------------------------------------------------------------
INSERT INTO	PlayerColors (Type, Usage, PrimaryColor, SecondaryColor, Alt1PrimaryColor, Alt1SecondaryColor, Alt2PrimaryColor, Alt2SecondaryColor, Alt3PrimaryColor, Alt3SecondaryColor )
VALUES ('LEADER_LUFFY_BDD_G4', 'Unique', 'COLOR_CORCEGA_A_PRIMARY_BDD_G4', 'COLOR_CORCEGA_A_SECONDARY_BDD_G4', 'COLOR_CORCEGA_B_PRIMARY_BDD_G4', 'COLOR_CORCEGA_B_SECONDARY_BDD_G4', 'COLOR_CORCEGA_C_PRIMARY_BDD_G4', 'COLOR_CORCEGA_C_SECONDARY_BDD_G4', 'COLOR_CORCEGA_D_PRIMARY_BDD_G4', 'COLOR_CORCEGA_D_SECONDARY_BDD_G4');